<?php

return array(
    'site-title' => "",
    'site-description' => "",
    'site-keywords' => "",
    'images-thumb-dir' => "/files/images/thumbnail",
    'notifications-enable' => "1",
    'content-prefix-enable' => "1",
    'category-prefix-enable' => "1",
    'category-page-last-enable' => "1",
    'comment-moderation-enable' => "1",
    'notification-email' => "",
    'comments-enable' => "1",
    'page-rows-admin' => "10",
    'uploads-dir' => "/files/uploads",
    'images-dir' => "/files/images",
    'page-rows' => "5",
    'sort-site' => "id",
    'sort-admin' => "position",
    'template' => "default",
    'api-token' => "hd9393hd03",
    'sitemap-enable' => "1",
    'robots-enable' => "1",
    'site-enable' => "1",
    'rss-enable' => "1",
    'api-enable' => "1",
    'robots-content' => "User-agent: *
Host: {host}
Sitemap: {host}/sitemap.xml",
    'timezone' => "Europe/Minsk",
    'license-key' => "cb7a1fe91",
    'installed' => "0",
);